# ZADATAK1:

# Definisanje širine i visine pravougaonika:
a = float(input("Unesite širinu pravougaonika: "))
b = float(input("Unesite visinu pravougaonika: "))

# Funkcija za izračunavanje površine pravougaonika
def povrsina_pravougaonika(a, b):
    return a * b

# Funkcija za izračunavanje obima pravougaonika
def obim_pravougaonika(a, b):
    return 2 * (a + b)

# Izračunavanje površine i obima
povrsina = povrsina_pravougaonika(a, b)
obim = obim_pravougaonika(a, b)

# Ispis rezultata
print(f"Površina pravougaonika je: {povrsina}")
print(f"Obim pravougaonika je: {obim}")

# ZADATAK2:

import math 

# Unos koeficijenata kvadratne jednačine 
a = float(input("Unesite koeficijent a: ")) 
b = float(input("Unesite koeficijent b: ")) 
c = float(input("Unesite koeficijent c: ")) 

# Izračunavanje diskriminante 
discriminant = b**2 - 4*a*c 

# Provjera da li je diskriminanta pozitivna ili jednaka nuli 
if discriminant >= 0: 

# Izračunavanje korena diskriminante 
sqrt_discriminant = math.sqrt(discriminant) 

# Izračunavanje rešenja x1 i x2 
x1 = (-b + sqrt_discriminant) / (2*a) 
x2 = (-b - sqrt_discriminant) / (2*a) 


# Ispis rešenja 
print(f"Rešenja kvadratne jednačine su: x1 = {x1}, x2 = {x2}") 
else: 
print("Diskriminanta je negativna, nema realnih rešenja.")

# ZADATAK3:

# Unos brojeva a i b
a = float(input("Unesite broj a: "))
b = float(input("Unesite broj b: "))

# Izračunavanje razlike kvadrata
razlika_kvadrata = a**2 - b**2

# Ispis rezultata
print(f"Razlika kvadrata brojeva {a} i {b} je: {razlika_kvadrata}")

# ZADATAK4: 

# Unos dimenzija terena
d = float(input("Unesite dužinu terena (d) u metrima: "))
s = float(input("Unesite širinu terena (s) u metrima: "))

# Izračunavanje obima terena
obim = 2 * (d + s)

# Izračunavanje pređene distance za 4 obilaska
ukupna_distanca = 4 * obim

# Ispis rezultata
print(f"Sportista pretrči ukupno {ukupna_distanca} metara dok obiđe teren 4 puta.")

# ZADATAK5:

# Unos širine i visine lista papira u milimetrima
sirina_mm = float(input("Unesite širinu lista papira u milimetrima: "))
visina_mm = float(input("Unesite visinu lista papira u milimetrima: "))

# Konverzija iz milimetara u centimetre
sirina_cm = sirina_mm / 10
visina_cm = visina_mm / 10

# Izračunavanje površine u kvadratnim centimetrima
povrsina_cm2 = sirina_cm * visina_cm

# Ispis rezultata
print(f"Površina lista papira je: {povrsina_cm2} kvadratnih centimetara.")

#  ZADATAK6:

# Unos vrijednosti a, b i c
a = float(input("Unesite vrijednost za a: "))
b = float(input("Unesite vrijednost za b: "))
c = float(input("Unesite vrijednost za c: "))

# Izračunavanje kvadrata trinoma koristeći formulu
kvadrat_trinoma = a**2 + b**2 + c**2 + 2*a*b + 2*a*c + 2*b*c

# Ispis rezultata
print(f"Kvadrat trinoma za a={a}, b={b}, c={c} je: {kvadrat_trinoma}")

# ZADATAK7:

import math

# Unos vremena u satima
time = float(input("Unesite vreme vožnje bicikla u satima: "))

# Izračunavanje litara vode koje Marko popije
litara = math.floor(time * 0.5)

# Ispis rezultata
print(f"Marko će popiti {litara} litara vode.")

# ZADATAK8:

import math

# Unos površine kruga
P = float(input("Unesite površinu stola u kvadratnim metrima: "))

# Izračunavanje poluprečnika r
r = math.sqrt(P / math.pi)

# Izračunavanje obima kruga (dužine trake)
obim = 2 * math.pi * r

# Ispis rezultata
print(f"Potrebna dužina trake za ivicu stolnjaka je: {obim} metara.")





# ZADATAK9:

# Unos dimenzija terena i rastojanja od ograde
d = int(input("Unesite dužinu terena u metrima: "))
s = int(input("Unesite širinu terena u metrima: "))
r = int(input("Unesite rastojanje ograde od terena u metrima: "))

# Izračunavanje dimenzija ograde
duzina_ograde = d + 2 * r
sirina_ograde = s + 2 * r

# Izračunavanje dužine ograde
duzina_ograde_total = 2 * (duzina_ograde + sirina_ograde)

# Ispis rezultata
print(f"Dužina ograde je: {duzina_ograde_total} metara.")

# ZADATAK10:

# Unos koordinata donje desne i gornje leve ivice zida
x1, y1 = map(float, input("Unesite koordinate donje desne ivice (x1, y1): ").split())
x2, y2 = map(float, input("Unesite koordinate gornje leve ivice (x2, y2): ").split())

# Izračunavanje dimenzija zida
duzina = x2 - x1
sirina = y1 - y2

# Izračunavanje površine zida
povrsina = duzina * sirina

# Izračunavanje obima zida
obim = 2 * (duzina + sirina)

# Ispis rezultata
print(f"Površina zida je: {povrsina} kvadratnih metara.")
print(f"Obim zida je: {obim} metara.")


# ZADATAK12:

# Unos trenutne godine i broja godina Miloša
trenutna_godina = int(input("Unesite trenutnu godinu: "))
n = int(input("Unesite koliko godina Miloš ima: "))

# Izračunavanje godine rođenja Miloša
godina_rodenja = trenutna_godina - n

# Ispis rezultata
print(f"Miloš je rođen {godina_rodenja}. godine.")

# ZADATAK13:

import math

# Unos koordinata hrasta i kuće
x1, y1 = map(float, input("Unesite koordinate hrasta (x1, y1): ").split())
x2, y2 = map(float, input("Unesite koordinate kuće (x2, y2): ").split())

# Izračunavanje koordinata blaga
x_b = x2 + 2
y_b = y2 - 3
print(f'Koordinate blaga su: ({x_b}, {y_b})')

# Izračunavanje vazdušnog rastojanja od hrasta do blaga
rastojanje_vazduhom = math.sqrt((x_b - x1) ** 2 + (y_b - y1) ** 2)
print(f'Vazdušno rastojanje od hrasta do blaga je: {rastojanje_vazduhom:.2f}')

# Izračunavanje rastojanja od hrasta do blaga obilazeći kuću
rastojanje_obilazak = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2) + math.sqrt((x_b - x2) ** 2 + (y_b - y2) ** 2)
print(f'Rastojanje od hrasta do blaga preko kuće je: {rastojanje_obilazak:.2f}')

# ZADATAK14:

# Unos parametara stana
velicina_stana = float(input("Unesite veličinu stana u kvadratnim metrima: "))
lokacija = int(input("Unesite zonu (1 za zona 1, 2 za zona 2, 3 za zona 3): "))
parking = int(input("Da li stan ima parking (1 za da, 0 za ne): "))

# Definisanje konstantnih vrijednosti
cijena_po_kvadratu = 1200
fiksna_cijena_ucesca = 1000

# Izračunavanje pondera
ponder_lokacija = 5 * lokacija
ponder_parking = 10 * parking

# Ukupna procjena cijene
ukupna_cijena = (velicina_stana + ponder_lokacija + ponder_parking) * cijena_po_kvadratu + fiksna_cijena_ucesca

# Ispis rezultata
print(f"Ukupna cijena stana je: {ukupna_cijena} eura")

# ZADATAK15:

import math

# Unos koordinata tjemena trougla
x1, y1 = map(float, input("Unesite koordinate prve tačke (x1, y1): ").split())
x2, y2 = map(float, input("Unesite koordinate druge tačke (x2, y2): ").split())
x3, y3 = map(float, input("Unesite koordinate treće tačke (x3, y3): ").split())

# Izračunavanje dužina stranica trougla
a = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
b = math.sqrt((x3 - x2) ** 2 + (y3 - y2) ** 2)
c = math.sqrt((x1 - x3) ** 2 + (y1 - y3) ** 2)

# Izračunavanje poluobima
s = (a + b + c) / 2

# Izračunavanje površine koristeći Heronovu formulu
povrsina = math.sqrt(s * (s - a) * (s - b) * (s - c))

# Ispis rezultata
print(f'Površina trougla je: {povrsina:.2f}')

# ZADATAK16:

# Definisanje cijena
cijena_po_km = 0.5  # cijena po kilometru u evrima
pocetna_cijena = 1  # pocetna cijena u evrima

# Unos broja pređenih kilometara
kilometri = float(input("Unesite broj pređenih kilometara: "))

# Izračunavanje ukupne cijene
ukupna_cijena = pocetna_cijena + (cijena_po_km * kilometri)

# Ispis rezultata
print(f"Ukupna cijena vožnje je: {ukupna_cijena:.2f} eura")

# ZADATAK17:

# Unos originalne cijene knjige
originalna_cijena = float(input("Unesite originalnu cijenu knjige u evrima: "))

# Unos procenta popusta
procenat_popusta = float(input("Unesite procenat popusta (npr. 20 za 20%): "))

# Izračunavanje iznosa popusta
iznos_popusta = (procenat_popusta / 100) * originalna_cijena

# Izračunavanje konačne cijene knjige
konacna_cijena = originalna_cijena - iznos_popusta

# Ispis rezultata
print(f"Konačna cijena knjige nakon popusta je: {konacna_cijena:.2f} eura")

# ZADATAK18:

# Unos početne cijene konzole
pocetna_cijena = float(input("Unesite početnu cijenu konzole u evrima: "))

# Povećanje cijene za 10%
cijena_nakon_povecanja = pocetna_cijena * 1.10

# Smanjenje cijene za 10% od nove cijene
konacna_cijena = cijena_nakon_povecanja * 0.90

# Ispis rezultata
print(f"Konačna cijena konzole nakon povećanja i smanjenja je: {konacna_cijena:.2f} eura")

# ZADATAK19:

# Unos trocifrenog broja
broj = int(input("Unesite trocifreni broj: "))

# Provjera da li je broj trocifren
if 100 <= broj <= 999:
    # Izdvajanje cifara
    stotine = broj // 100
    desetice = (broj // 10) % 10
    jedinice = broj % 10

    # Izračunavanje zbira cifara
    zbir_cifara = stotine + desetice + jedinice

    # Ispis rezultata
    print(f"Zbir cifara broja {broj} je: {zbir_cifara}")
else:
    print("Uneseni broj nije trocifren.")

# ZADATAK20:

# Unos trocifrenog broja
broj = int(input("Unesite trocifreni broj: "))

# Provjera da li je broj trocifren
if 100 <= broj <= 999:
    # Izdvajanje cifara
    stotine = broj // 100
    desetice = (broj // 10) % 10
    jedinice = broj % 10

    # Izračunavanje proizvoda cifara
    proizvod_cifara = stotine * desetice * jedinice

    # Izračunavanje zbira cifara
    zbir_cifara = stotine + desetice + jedinice

    # Izračunavanje koda za otvaranje vrata
    kod = proizvod_cifara - zbir_cifara

    # Ispis rezultata
    print(f"Kod za otvaranje vrata je: {kod}")
else:
    print("Uneseni broj nije trocifren.")

# ZADATAK21:

# Unos četvorocifrenog broja
broj = int(input("Unesite četvorocifreni broj: "))

# Provjera da li je broj četvorocifren
if 1000 <= broj <= 9999:
    # Izdvajanje cifara
    prva_cifra = broj // 1000
    druga_cifra = (broj // 100) % 10
    treca_cifra = (broj // 10) % 10
    poslednja_cifra = broj % 10

    # Izračunavanje kvadrata zbira prve i poslednje cifre
    zbir_prva_poslednja = prva_cifra + poslednja_cifra
    kvadrat_zbira = zbir_prva_poslednja ** 2

    # Izračunavanje razlike kvadrata druge i treće cifre
    kvadrat_druga = druga_cifra ** 2
    kvadrat_treca = treca_cifra ** 2
    razlika_kvadrata = kvadrat_druga - kvadrat_treca

    # Izračunavanje šifre
    sifra = kvadrat_zbira - razlika_kvadrata

    # Ispis rezultata
    print(f"Šifra koja otvara sef je: {sifra}")
else:
    print("Uneseni broj nije četvorocifren.")

# ZADATAK22:

# Unos podataka
N = int(input("Unesite ukupni broj učenika: "))
K = int(input("Unesite broj učenika na drugoj strani: "))
p1 = float(input("Unesite prosječan broj poena na prvoj strani: "))
p2 = float(input("Unesite prosječan broj poena na drugoj strani: "))

# Izračunavanje broja učenika na prvoj strani
broj_ucenika_prva_strana = N - K

# Izračunavanje ukupnog broja poena na prvoj i drugoj strani
ukupni_poen_prva_strana = p1 * broj_ucenika_prva_strana
ukupni_poen_druga_strana = p2 * K

# Ukupni broj poena za sve učenike
ukupni_poen = ukupni_poen_prva_strana + ukupni_poen_druga_strana

# Izračunavanje prosječnog broja poena za sve učenike
prosjecni_poen = ukupni_poen / N

# Ispis rezultata
print(f"Prosječan broj poena svih učenika je: {prosjecni_poen:.2f}")

# ZADATAK23:

# Unos parametara a i b
a = float(input("Unesite prvi broj (a): "))
b = float(input("Unesite drugi broj (b): "))

# Izračunavanje srednje vrijednosti
srednja_vrijednost = (a + b) / 2

# Ispis rezultata
print(f"Srednja vrijednost brojeva {a} i {b} je: {srednja_vrijednost}")



# ZADATAK24:

# Unos vrijednosti za x i y
x = int(input("Unesite vrijednost za x: "))
y = int(input("Unesite vrijednost za y: "))

# Prikaz vrijednosti pre zamene
print(f"Pre zamene: x = {x}, y = {y}")

# Zamena vrijednosti između x i y
x, y = y, x

# Prikaz vrijednosti posle zamene
print(f"Posle zamene: x = {x}, y = {y}")

# ZADATAK25:

# Unos rastojanja u centimetrima
rastojanje_cm = int(input("Unesite rastojanje u centimetrima: "))

# Izračunavanje broja celih metara
broj_celih_metara = rastojanje_cm // 100

# Ispis rezultata
print(f"Broj celih metara u rastojanju od {rastojanje_cm} cm je: {broj_celih_metara}")


# ZADATAK26:

# Unos rastojanja u centimetrima
rastojanje_cm = int(input("Unesite rastojanje u centimetrima: "))

# Izračunavanje broja celih metara
broj_celih_metara = rastojanje_cm // 100

# Ispis rezultata
print(f"Broj celih metara u rastojanju od {rastojanje_cm} cm je: {broj_celih_metara}")

# ZADATAK27:

# Unos četvorocifrenog broja
broj = int(input("Unesite četvorocifreni broj: "))

# Provjera da li je broj četvorocifren
if 1000 <= broj <= 9999:
    # Izdvajanje cifara
    prva_cifra = broj // 1000
    druga_cifra = (broj // 100) % 10
    treca_cifra = (broj // 10) % 10
    poslednja_cifra = broj % 10

    # Izračunavanje zbira cifara
    zbir_cifara = prva_cifra + druga_cifra + treca_cifra + poslednja_cifra

    # Izračunavanje kvadrata zbira
    kvadrat_zbira = zbir_cifara ** 2

    # Ispis rezultata
    print(f"Kvadrat zbira cifara broja {broj} je: {kvadrat_zbira}")
else:
    print("Uneseni broj nije četvorocifren.")

# ZADATAK28:

# Unos trocifrenog broja
broj = int(input("Unesite trocifreni broj: "))

# Provjera da li je broj trocifren
if 100 <= broj <= 999:
    # Izdvajanje cifara
    prva_cifra = broj // 100
    srednja_cifra = (broj // 10) % 10
    poslednja_cifra = broj % 10

    # Formiranje novog broja sa zamenjenim prvom i poslednjom cifrom
    novi_broj = poslednja_cifra * 100 + srednja_cifra * 10 + prva_cifra

    # Ispis rezultata
    print(f"Broj sa zamenjenom prvom i poslednjom cifrom je: {novi_broj}")
else:
    print("Uneseni broj nije trocifren.")

# ZADATAK29:

import math

# Unos koordinata početnih tačaka
x1, y1 = map(float, input("Unesite koordinate prve tačke (x1 y1): ").split())
x2, y2 = map(float, input("Unesite koordinate druge tačke (x2 y2): ").split())

# Izračunavanje koordinata tačke susreta
x3 = (x1 + x2) / 2
y3 = (y1 + y2) / 2

# Izračunavanje Euklidskog rastojanja
rastojanje = math.sqrt((x3 - x1) ** 2 + (y3 - y1) ** 2)

# Ispis rezultata
print(f"Koordinate tačke susreta su: ({x3}, {y3})")
print(f"Rastojanje od početne tačke do tačke susreta je: {rastojanje:.2f}")

# ZADATAK30:

# Dimenzije pravougaonika
sirina = 543
visina = 130

# Dimenzija kvadrata
stranica_kvadrata = 65

# Izračunavanje broja kvadrata po širini i visini
kvadrati_po_sirini = sirina // stranica_kvadrata
kvadrati_po_visini = visina // stranica_kvadrata

# Izračunavanje ukupnog broja kvadrata
ukupno_kvadrata = kvadrati_po_sirini * kvadrati_po_visini

# Ispis rezultata
print(f"Broj kvadrata stranice {stranica_kvadrata} koji se može izrezati iz pravougaonika dimenzija {sirina} x {visina} je: {ukupno_kvadrata}")

# ZADATAK31:

import math

# Poznate vrijednosti
d = 50  # dužina dijagonale
aspect_ratio_width = 16
aspect_ratio_height = 9

# Izračunavanje x pomoću Pitagorine teoreme
x = math.sqrt(d**2 / (aspect_ratio_width**2 + aspect_ratio_height**2))

# Izračunavanje dimenzija ekrana
width = aspect_ratio_width * x
height = aspect_ratio_height * x

# Izračunavanje površine ekrana
povrsina = width * height

# Ispis rezultata
print(f"Dimenzije ekrana su: Širina = {width:.2f} cm, Visina = {height:.2f} cm")
print(f"Površina ekrana je: {povrsina:.2f} cm²")

# ZADATAK32:

# Unos šestocifrenog broja
n = int(input("Unesite šestocifreni broj: "))

# Provjeravamo da li je broj šestocifren
if n < 100000 or n > 999999:
    print("Broj nije šestocifren.")
else:
    # Ekstrahovanje cifara
    a = n // 100000          # Prva cifra
    b = (n // 10000) % 10    # Druga cifra
    c = (n // 1000) % 10     # Treća cifra
    d = (n // 100) % 10      # Četvrta cifra
    e = (n // 10) % 10       # Peta cifra
    f = n % 10               # Šesta cifra

    # Izračunavanje obe strane izraza
    leva_strana = a * c + 2 + f
    desna_strana = b + d * e

    # Provjera uslova
    if leva_strana == desna_strana:
        print("Uslov je zadovoljen.")
    else:
        print("Uslov nije zadovoljen.")

# ZADATAK33:

# Unos dimenzija poljane
sirina_poljane = float(input("Unesite širinu poljane u metrima: "))
duzina_poljane = float(input("Unesite dužinu poljane u metrima: "))

# Unos dimenzija kvadrata
stranica_kvadrata = float(input("Unesite dimenziju kvadrata u metrima: "))

# Izračunavanje broja kvadrata po širini i dužini
kvadrati_po_sirini = sirina_poljane // stranica_kvadrata
kvadrati_po_duzini = duzina_poljane // stranica_kvadrata

# Izračunavanje ukupnog broja kvadrata
ukupno_kvadrata = int(kvadrati_po_sirini * kvadrati_po_duzini)

# Ispis rezultata
print(f"Broj kvadrata dimenzija {stranica_kvadrata}m x {stranica_kvadrata}m koji se može kreirati na poljani dimenzija {sirina_poljane}m x {duzina_poljane}m je: {ukupno_kvadrata}")

# ZADATAK34:

# Unos šestocifrenog broja
n = int(input("Unesite šestocifreni broj: "))

# Provjeravamo da li je broj šestocifren
if n < 100000 or n > 999999:
    print("Broj nije šestocifren.")
else:
    # Ekstrahovanje cifara
    a = n // 100000          # Prva cifra
    b = (n // 10000) % 10    # Druga cifra
    c = (n // 1000) % 10     # Treća cifra
    d = (n // 100) % 10      # Četvrta cifra
    e = (n // 10) % 10       # Peta cifra
    f = n % 10               # Šesta cifra

    # Izračunavanje sume svih cifara
    suma_cifara = a + b + c + d + e + f

    # Kvadriranje sume cifara
    kvadrat_sume = suma_cifara ** 2

    # Izračunavanje proizvoda treće i četvrte cifre
    proizvod_cifara = c * d

    # Izračunavanje identifikacionog broja
    identifikacioni_broj = kvadrat_sume - proizvod_cifara

    # Ispis rezultata
    print(f"Identifikacioni broj je: {identifikacioni_broj}")

# ZADATAK35:

# Unos petocifrenog broja
broj = int(input("Unesite petocifreni broj: "))

# Provjeravamo da li je broj petocifren
if broj < 10000 or broj > 99999:
    print("Broj nije petocifren.")
else:
    # Ekstrahovanje cifara
    prva_cifra = broj // 10000           # Prva cifra
    druga_cifra = (broj // 1000) % 10    # Druga cifra
    treca_cifra = (broj // 100) % 10     # Treća cifra (srednja cifra)
    cetvrta_cifra = (broj // 10) % 10    # Četvrta cifra
    peta_cifra = broj % 10               # Peta cifra (poslednja cifra)

    # Izračunavanje zbira srednje cifre i poslednje cifre
    zbir = treca_cifra + peta_cifra

    # Ispis rezultata
    print(f"Sprat na kojem se nalazi stambena jedinica je: {zbir}")

